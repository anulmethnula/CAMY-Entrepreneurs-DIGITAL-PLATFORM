CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  member_id VARCHAR(30) NULL UNIQUE,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  session_version INT UNSIGNED NOT NULL DEFAULT 1,
  access_role VARCHAR(40) NULL,
  permissions_json TEXT NULL,
  role ENUM('admin','manager','staff','entrepreneur') NOT NULL DEFAULT 'entrepreneur',
  status ENUM('active','suspended','inactive') NOT NULL DEFAULT 'active',
  last_login_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX users_role_status_member (role,status,member_id)
) ENGINE=InnoDB AUTO_INCREMENT=1000;

CREATE TABLE IF NOT EXISTS staff_access_roles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(40) NOT NULL UNIQUE,
  permissions_json TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=1000;

CREATE TABLE IF NOT EXISTS entrepreneurs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NULL,
  member_id VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(150) NULL,
  email VARCHAR(190) NULL,
  nic VARCHAR(30) NULL UNIQUE,
  nic_image_path VARCHAR(255) NULL,
  phone VARCHAR(30) NULL,
  address TEXT NULL,
  city VARCHAR(100) NULL,
  joined_date DATE NOT NULL,
  profile_image LONGTEXT NULL,
  bank_name VARCHAR(120) NULL,
  bank_branch VARCHAR(120) NULL,
  account_holder VARCHAR(150) NULL,
  account_number VARCHAR(80) NULL,
  credit_limit DECIMAL(14,2) NOT NULL DEFAULT 0,
  outstanding DECIMAL(14,2) NOT NULL DEFAULT 0,
  total_sales DECIMAL(14,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1000;

CREATE TABLE IF NOT EXISTS products (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(60) NOT NULL UNIQUE,
  name VARCHAR(190) NOT NULL,
  category VARCHAR(100) NOT NULL,
  description TEXT NULL,
  price DECIMAL(14,2) NOT NULL,
  billing_price DECIMAL(14,2) NULL,
  delivery_cost DECIMAL(14,2) NOT NULL DEFAULT 0,
  packaging_cost DECIMAL(14,2) NOT NULL DEFAULT 0,
  free_delivery TINYINT(1) NOT NULL DEFAULT 1,
  stock INT UNSIGNED NOT NULL DEFAULT 0,
  image LONGTEXT NULL,
  record_json LONGTEXT NULL,
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=1000;

CREATE TABLE IF NOT EXISTS marketplace_state (
  id TINYINT UNSIGNED PRIMARY KEY,
  state_json LONGTEXT NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO marketplace_state(id,state_json) VALUES(1,'{}') ON DUPLICATE KEY UPDATE id=id;

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NULL,
  action VARCHAR(12) NOT NULL,
  resource VARCHAR(255) NOT NULL,
  status_code SMALLINT UNSIGNED NOT NULL,
  ip_address VARCHAR(45) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX audit_user_time(user_id,created_at)
) ENGINE=InnoDB AUTO_INCREMENT=1000;

-- Shop-flow records for reporting and future migration away from the JSON snapshot.
CREATE TABLE IF NOT EXISTS stock_supply_requests (
  id VARCHAR(32) PRIMARY KEY,
  entrepreneur_member_id VARCHAR(30) NOT NULL,
  payment_reference VARCHAR(120) NOT NULL,
  receipt_path VARCHAR(255) NOT NULL,
  total DECIMAL(14,2) NOT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME NULL,
  record_json LONGTEXT NULL,
  INDEX supply_member_status_created (entrepreneur_member_id,status,created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stock_supply_request_items (
  request_id VARCHAR(32) NOT NULL,
  product_code VARCHAR(60) NOT NULL,
  quantity INT UNSIGNED NOT NULL,
  purchase_price DECIMAL(14,2) NOT NULL,
  PRIMARY KEY (request_id, product_code),
  FOREIGN KEY (request_id) REFERENCES stock_supply_requests(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS entrepreneur_shop_items (
  entrepreneur_member_id VARCHAR(30) NOT NULL,
  product_code VARCHAR(60) NOT NULL,
  quantity INT UNSIGNED NOT NULL DEFAULT 0,
  sell_price DECIMAL(14,2) NOT NULL,
  visible TINYINT(1) NOT NULL DEFAULT 1,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (entrepreneur_member_id, product_code)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS customer_order_groups (
  id VARCHAR(32) PRIMARY KEY,
  customer_name VARCHAR(150) NOT NULL,
  customer_phone VARCHAR(30) NOT NULL,
  district VARCHAR(100) NOT NULL,
  delivery_address TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS shop_orders (
  id VARCHAR(32) PRIMARY KEY,
  group_id VARCHAR(32) NOT NULL,
  entrepreneur_member_id VARCHAR(30) NOT NULL,
  total DECIMAL(14,2) NOT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'Pending',
  delivered_at DATETIME NULL,
  record_json LONGTEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX shop_orders_member_status_delivery (entrepreneur_member_id,status,delivered_at),
  FOREIGN KEY (group_id) REFERENCES customer_order_groups(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS shop_order_items (
  order_id VARCHAR(32) NOT NULL,
  product_code VARCHAR(60) NOT NULL,
  quantity INT UNSIGNED NOT NULL,
  sell_price DECIMAL(14,2) NOT NULL,
  PRIMARY KEY (order_id, product_code),
  FOREIGN KEY (order_id) REFERENCES shop_orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS entrepreneur_payouts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id VARCHAR(32) NOT NULL UNIQUE,
  entrepreneur_member_id VARCHAR(30) NOT NULL,
  client_payment_method ENUM('cod','bank') NOT NULL DEFAULT 'cod',
  client_total DECIMAL(14,2) NOT NULL,
  camy_cost DECIMAL(14,2) NOT NULL,
  payout_amount DECIMAL(14,2) NOT NULL,
  client_payment_reference VARCHAR(120) NULL,
  client_payment_receipt_path VARCHAR(255) NULL,
  collection_status ENUM('pending','collected','failed') NOT NULL DEFAULT 'pending',
  payout_status ENUM('pending_delivery','pending_transfer','paid','reversal_required','cancelled') NOT NULL DEFAULT 'pending_delivery',
  payout_reference VARCHAR(120) NULL,
  payout_receipt_path VARCHAR(255) NULL,
  collected_at DATETIME NULL,
  payout_due_at DATETIME NULL,
  paid_at DATETIME NULL,
  recorded_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX payout_member_status (entrepreneur_member_id,payout_status),
  INDEX payout_due_status (payout_status,payout_due_at),
  INDEX payout_paid_at (paid_at),
  FOREIGN KEY (order_id) REFERENCES shop_orders(id) ON DELETE CASCADE,
  FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1000;

CREATE TABLE IF NOT EXISTS credit_tiers (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  sales_required DECIMAL(14,2) NOT NULL,
  credit_limit DECIMAL(14,2) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  record_json LONGTEXT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1000;

CREATE TABLE IF NOT EXISTS platform_settings (
  setting_key VARCHAR(80) PRIMARY KEY,
  value_json LONGTEXT NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS entrepreneur_directory (
  member_id VARCHAR(30) PRIMARY KEY,
  record_json LONGTEXT NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS credit_settlement_requests (
  id VARCHAR(32) PRIMARY KEY,
  entrepreneur_member_id VARCHAR(30) NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  reference VARCHAR(100) NOT NULL,
  status VARCHAR(40) NOT NULL,
  record_json LONGTEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX settlement_member_status(entrepreneur_member_id,status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS registration_requests (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  nic VARCHAR(30) NOT NULL,
  address TEXT NOT NULL,
  city VARCHAR(100) NOT NULL,
  occupation VARCHAR(150) NOT NULL,
  has_online_business ENUM('yes','no') NOT NULL DEFAULT 'no',
  online_business_products VARCHAR(255) NULL,
  online_business_duration VARCHAR(120) NULL,
  monthly_income VARCHAR(120) NULL,
  social_media_url VARCHAR(500) NULL,
  followers_count INT UNSIGNED NULL,
  facebook_marketing ENUM('yes','a_little','no') NOT NULL DEFAULT 'no',
  join_reason TEXT NOT NULL,
  agreement_accepted TINYINT(1) NOT NULL DEFAULT 0,
  nic_image_path VARCHAR(255) NULL,
  nic_front_path VARCHAR(255) NULL,
  nic_back_path VARCHAR(255) NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  admin_note TEXT NULL,
  reviewed_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME NULL,
  INDEX registration_email_status (email, status),
  INDEX registration_nic_status (nic, status),
  INDEX registration_status_created (status, created_at),
  INDEX registration_city (city),
  FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1000;

CREATE TABLE IF NOT EXISTS login_attempts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL,
  ip_address VARCHAR(45) NOT NULL,
  succeeded TINYINT(1) NOT NULL DEFAULT 0,
  attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX login_limit (email, ip_address, attempted_at)
) ENGINE=InnoDB AUTO_INCREMENT=1000;
